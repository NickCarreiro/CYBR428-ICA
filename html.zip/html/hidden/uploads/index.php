<?php
// uploads/index.php - simple upload form and listing
$flag = 'FLAG{uploads_hit_91ac0}';
?>
<!doctype html>
<html><head>
  <link rel="stylesheet" href="/hidden/assets/style.css"><meta charset="utf-8"><title>Uploads</title></head>
<body>
  <h1>Uploads</h1>
  <p>Upload a small file (txt, jpg, png, pdf). Max 2MB.</p>
  <form action="upload.php" method="post" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <input type="submit" value="Upload">
  </form>

  <h2>Stored files</h2>
  <ul>
<?php
$dir = __DIR__ . '/storage';
if (is_dir($dir)) {
  $files = array_diff(scandir($dir), array('.', '..'));
  foreach ($files as $f) {
    $safe = htmlspecialchars($f);
    echo "<li><a href=\"/hidden/uploads/storage/$safe\">$safe</a></li>";
  }
}
?>
  </ul>

  <p><strong>Flag:</strong> <?php echo $flag; ?></p>
</body>
</html>
