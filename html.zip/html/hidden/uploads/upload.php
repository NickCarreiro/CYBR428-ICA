<link rel="stylesheet" href="/hidden/assets/style.css">
<?php
// uploads/upload.php - validate and store uploads (whitelist extensions)
$maxBytes = 2 * 1024 * 1024; // 2 MB
$allowed = ['txt','jpg','jpeg','png','pdf'];
$dstDir = __DIR__ . '/storage';
if (!is_dir($dstDir)) mkdir($dstDir, 0755, true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['file'])) {
  http_response_code(400);
  echo "No file uploaded.";
  exit;
}

$file = $_FILES['file'];
if ($file['error'] !== UPLOAD_ERR_OK) {
  http_response_code(400);
  echo "Upload error.";
  exit;
}
if ($file['size'] > $maxBytes) {
  http_response_code(400);
  echo "File too large (max 2MB).";
  exit;
}
$orig = basename($file['name']);
$ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
if (!in_array($ext, $allowed)) {
  http_response_code(400);
  echo "Extension not allowed.";
  exit;
}

// create safe filename (timestamp + random)
$fname = time() . '_' . bin2hex(random_bytes(6)) . '_' . preg_replace('/[^A-Za-z0-9._-]/','_', $orig);
$dest = $dstDir . '/' . $fname;
if (!move_uploaded_file($file['tmp_name'], $dest)) {
  http_response_code(500);
  echo "Failed to save file.";
  exit;
}
// set perms and record metadata
@chmod($dest, 0644);
$meta = sprintf("[%s] %s %d bytes\n", date('c'), $fname, filesize($dest));
file_put_contents(__DIR__ . '/uploads.log', $meta, FILE_APPEND | LOCK_EX);
@chmod(__DIR__ . '/uploads.log', 0640);
echo "Upload saved as: " . htmlspecialchars($fname);
?>
