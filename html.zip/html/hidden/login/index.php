<?php
// login/index.php - improved layout + flag display
// Show errors in-page for quick debugging (remove in production)
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

// Try to read the flag file placed in the same directory
$flag_path = __DIR__ . '/flag.txt';
$flag = 'FLAG NOT FOUND';
if (is_readable($flag_path)) {
    $f = trim((string)@file_get_contents($flag_path));
    if ($f !== '') { $flag = $f; }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login Portal</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="/hidden/assets/style.css">
  <style>
    /* Small local helpers to ensure consistent form sizing */
    .form-row { display:flex; flex-direction:column; gap:6px; margin-bottom:12px; max-width:640px; }
    .form-row label { font-weight:600; color:var(--text); }
    .form-row input[type="text"], .form-row input[type="password"] {
      width:100%; min-height:42px; box-sizing:border-box;
      padding:10px 12px; border-radius:8px; border:1px solid var(--border);
      background:var(--input); color:var(--text);
    }
    .form-actions { margin-top:10px; display:flex; gap:10px; align-items:center; }
    .flag-inline { margin-left:8px; vertical-align:middle; }
    .small-note { color:var(--muted); margin-top:8px; font-size:13px; max-width:640px; }
  </style>
</head>
<body class="container">
  <header class="nav">
    <h1>Login Portal</h1>
    <p class="meta">Server: <strong><?php echo htmlspecialchars(gethostname()); ?></strong></p>
  </header>

  <main>
    <section class="card" style="max-width:760px;">
      <h2>Sign in to the internal portal</h2>
      <form action="authenticate.php" method="post" class="login-form" autocomplete="off">
        <div class="form-row">
          <label for="user">Username:</label>
          <input id="user" name="user" type="text" required autocomplete="username" />
        </div>
        <div class="form-row">
          <label for="pass">Password:</label>
          <input id="pass" name="pass" type="password" required autocomplete="current-password" />
        </div>

        <div class="form-actions">
          <button type="submit" class="btn">Login</button>
          <div class="small-note">For training purposes, credentials are logged on the server.</div>
        </div>
      </form>

      <hr>

      <div style="display:flex;align-items:center;gap:12px;">
        <div>
          <strong class="small">Challenge flag (file):</strong>
        </div>
        <div class="flag-inline">
          <span class="flag"><?php echo htmlspecialchars($flag); ?></span>
        </div>
      </div>

      <p class="small-note">Tip: This portal is a decoy honeypot — submissions are saved to <code>auth.log</code> in this directory.</p>
    </section>
  </main>
</body>
</html>
