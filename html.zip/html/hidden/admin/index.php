<?php
// admin/index.php - simple dashboard
session_start();
$flag = 'FLAG{admin_found_4f3c1}';
?>
<!doctype html>
<html lang="en">
<head>
  <link rel="stylesheet" href="/hidden/assets/style.css"><meta charset="utf-8"><title>Admin Dashboard</title></head>
<body>
  <h1>Admin Dashboard</h1>
  <p>Welcome to the administrative console.</p>
  <section>
    <h2>Site summary</h2>
    <ul>
      <li>Users total: 1,234</li>
      <li>Uploads: <?php echo is_dir(__DIR__ . '/../uploads/storage') ? count(scandir(__DIR__ . '/../uploads/storage')) - 2 : 0; ?></li>
      <li>Last scanner: <?php echo htmlspecialchars(@file_get_contents(__DIR__ . '/last_scanner.txt') ?: 'none'); ?></li>
    </ul>
  </section>

  <section>
    <h2>Flag</h2>
    <pre><?php echo $flag; ?></pre>
  </section>

  <p><a href="/hidden/wp-admin/">Go to wp-admin</a> • <a href="/hidden/uploads/">Uploads</a></p>
</body>
</html>
